import React, { useState, useEffect } from "react";
import { Route, Routes , Link, NavLink} from "react-router-dom";


const Header2 = (props) => {



 return(
     <>
       <div className="header">
            <div className="container">
                <div className="rowlane">
                <div className="logo"><img src="https://www.nsbpictures.com/wp-content/uploads/2019/11/logo-icon-png-8.png"/></div>
               
                </div>
            </div>
      </div>
         
     </>
 )

};
export default Header2;
