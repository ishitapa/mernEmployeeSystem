

const Loader = () => {
  return (
    <>
      <div className="loaderOuter">
        <div className="loaderInner">
          <span>Wait!!!!</span>
        </div>
      </div>
    </>
  );
};
export default Loader;
